# emailcontroller

A python library to facilitate email sending and reading.